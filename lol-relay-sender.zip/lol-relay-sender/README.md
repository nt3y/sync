# LoL Relay Sender (Node.js Version)

A Node.js implementation of the LoL Game Relay Sender for macOS, featuring a terminal-based UI and an automated setup script.

## Features
- **Auto-Setup**: Includes a `setup.sh` script that checks for Node.js and installs it via Homebrew if missing.
- **Modern UI**: Uses `inquirer` for an interactive command-line interface.
- **Process Monitoring**: Watches for League of Legends game processes, captures launch arguments, and relays them to a Windows receiver.
- **Automatic Cleanup**: Automatically terminates the local game process after capturing data.

## How to Run on macOS

1. **Download/Extract** the project folder.
2. **Open Terminal** and navigate to the folder:
   ```bash
   cd path/to/lol-relay-sender
   ```
3. **Run the Setup Script**:
   ```bash
   ./setup.sh
   ```
   *The script will automatically handle Node.js installation (if needed) and start the application.*

## Configuration
Once the app is running, you can:
- **Start Watching**: Begin monitoring for the game process.
- **Change Configuration**: Update the Receiver's IP address and Port.
- **Show Status**: View the current monitoring state and total successful transfers.

## Dependencies
The `setup.sh` script installs these automatically:
- `ps-list`: For process monitoring.
- `chalk`: For colored terminal output.
- `boxen`: For stylish UI boxes.
- `inquirer`: For interactive menus.
- `net`: Node.js built-in for TCP communication.

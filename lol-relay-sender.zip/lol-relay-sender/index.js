const fs = require('fs');
const path = require('path');
const net = require('net');
const psList = require('ps-list');
const chalk = require('chalk');
const boxen = require('boxen');
const inquirer = require('inquirer');
const { execSync, spawn } = require('child_process');

// --- Configuration ---
const DEFAULT_RECEIVER_IP = "192.168.1.XXX";
const DEFAULT_RECEIVER_PORT = 54321;
const POLL_INTERVAL = 1000; // ms

const GAME_KEYWORDS = ["leagueoflegends", "league of legends"];
const EXCLUDE_KEYWORDS = ["leagueclient", "leagueclientux", "riotclientservices", "riotclientux", "patcher", "crashhandler"];

const CMDLINE_WAIT_TIMEOUT = 10000; // ms
const CMDLINE_POLL = 300; // ms

// --- State ---
let watching = false;
let seenPids = new Set();
let transfers = 0;
let config = {
    ip: DEFAULT_RECEIVER_IP,
    port: DEFAULT_RECEIVER_PORT
};

// --- Helpers ---
function log(msg, color = 'white', bold = false) {
    const ts = new Date().toLocaleTimeString();
    let styledMsg = chalk[color](msg);
    if (bold) styledMsg = chalk.bold(styledMsg);
    console.log(`${chalk.gray(`[${ts}]`)}  ${styledMsg}`);
}

function getStatusText() {
    const status = watching ? chalk.green.bold('WATCHING') : chalk.red.bold('IDLE');
    return `STATUS: ${status} | TRANSFERS: ${chalk.cyan(transfers)}`;
}

async function getProcessDetails(pid) {
    // ps-list doesn't always provide full cmdline on all platforms easily
    // On macOS/Linux we can use ps command for more details if needed
    try {
        if (process.platform === 'darwin' || process.platform === 'linux') {
            const cmd = `ps -p ${pid} -o command=`;
            const fullCmd = execSync(cmd).toString().trim();
            
            // For environment variables, on macOS it's harder without sudo/root for other procs
            // We'll try to get what we can.
            return { cmdline: fullCmd.split(' ') };
        }
    } catch (e) {
        return null;
    }
    return null;
}

async function isGameProcess(proc) {
    const name = (proc.name || "").toLowerCase();
    const cmdline = (proc.cmdline || "").toLowerCase();
    const identity = `${name} ${cmdline}`;

    if (!GAME_KEYWORDS.some(k => identity.includes(k))) return false;
    if (EXCLUDE_KEYWORDS.some(k => identity.includes(k))) return false;
    
    return true;
}

async function sendInfo(info) {
    return new Promise((resolve) => {
        const payload = Buffer.from(JSON.stringify(info), 'utf8');
        const client = new net.Socket();
        
        client.setTimeout(10000);

        client.connect(config.port, config.ip, () => {
            const header = Buffer.alloc(8);
            header.writeBigInt64BE(BigInt(payload.length));
            client.write(header);
            client.write(payload);
            client.end();
        });

        client.on('end', () => {
            resolve({ ok: true, msg: `✓ Sent ${payload.length.toLocaleString()} bytes to ${config.ip}:${config.port}` });
        });

        client.on('error', (err) => {
            resolve({ ok: false, msg: `✗ Network error: ${err.message}` });
        });

        client.on('timeout', () => {
            client.destroy();
            resolve({ ok: false, msg: `✗ Timeout connecting to ${config.ip}:${config.port}` });
        });
    });
}

async function killProcess(pid) {
    try {
        process.kill(pid, 'SIGTERM');
        return "SIGTERM — graceful";
    } catch (e) {
        try {
            process.kill(pid, 'SIGKILL');
            return "SIGKILL — forced";
        } catch (err) {
            return `Failed to kill: ${err.message}`;
        }
    }
}

async function captureAndRelay(proc) {
    log(`Game process found: PID=${proc.pid} Name=${proc.name}`, 'green', true);
    
    // Wait for full cmdline (simplified for Node)
    let details = await getProcessDetails(proc.pid);
    let cmdline = details ? details.cmdline : [proc.name];
    
    log(`Args captured: ${cmdline.length} tokens`, 'green');
    
    const info = {
        pid: proc.pid,
        name: proc.name,
        cmdline: cmdline,
        created: Date.now(),
        environ: {} // Environ is tricky on macOS without specific native modules
    };

    // Kill
    const killResult = await killProcess(proc.pid);
    log(`Local process killed: ${killResult}`, 'yellow');

    // Send
    log(`Sending to ${config.ip}:${config.port} ...`, 'cyan');
    const result = await sendInfo(info);
    log(result.msg, result.ok ? 'green' : 'red', true);

    if (result.ok) {
        transfers++;
        console.log(getStatusText());
    }
}

async function watchLoop() {
    while (watching) {
        try {
            const list = await psList();
            for (const proc of list) {
                if (!watching) break;
                if (seenPids.has(proc.pid)) continue;
                
                if (await isGameProcess(proc)) {
                    seenPids.add(proc.pid);
                    captureAndRelay(proc);
                }
            }
        } catch (e) {
            log(`Error in watch loop: ${e.message}`, 'red');
        }
        await new Promise(r => setTimeout(r, POLL_INTERVAL));
    }
}

// --- UI ---
async function mainMenu() {
    console.clear();
    console.log(boxen(chalk.yellow.bold("⚡ LoL RELAY · SENDER [macOS] — NODE.JS"), { padding: 1, margin: 1, borderStyle: 'double', borderColor: 'yellow' }));
    console.log(chalk.gray(`  Target: ${chalk.cyan(`${config.ip}:${config.port}`)}`));
    console.log(chalk.gray(`  Status: ${getStatusText()}\n`));

    const { command } = await inquirer.prompt([
        {
            type: 'list',
            name: 'command',
            message: 'What would you like to do?',
            choices: [
                { name: watching ? 'Stop Watching' : 'Start Watching', value: 'toggle' },
                { name: 'Change Configuration', value: 'config' },
                { name: 'Show Status', value: 'status' },
                { name: 'Quit', value: 'quit' }
            ]
        }
    ]);

    switch (command) {
        case 'toggle':
            watching = !watching;
            if (watching) {
                seenPids.clear();
                watchLoop();
                log("Watcher started — waiting for game ...", 'yellow', true);
            } else {
                log("Watcher stopped.", 'gray');
            }
            break;
        case 'config':
            const answers = await inquirer.prompt([
                { name: 'ip', message: 'Receiver IP:', default: config.ip },
                { name: 'port', message: 'Receiver Port:', default: config.port.toString() }
            ]);
            config.ip = answers.ip;
            config.port = parseInt(answers.port) || DEFAULT_RECEIVER_PORT;
            break;
        case 'status':
            console.log(boxen(getStatusText(), { padding: 0.5, borderColor: 'cyan' }));
            break;
        case 'quit':
            process.exit(0);
    }
    
    setTimeout(mainMenu, 500);
}

mainMenu();

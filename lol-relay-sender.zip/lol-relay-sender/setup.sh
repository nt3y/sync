#!/bin/bash

# LoL Relay Sender - macOS Bootstrap Script
# This script ensures Node.js is installed, installs dependencies, and runs the app.

BOLD="\033[1m"
GREEN="\033[32m"
YELLOW="\033[33m"
RED="\033[31m"
RESET="\033[0m"

echo -e "${BOLD}${YELLOW}====================================================${RESET}"
echo -e "${BOLD}${YELLOW}   ⚡ LoL RELAY SENDER - macOS SETUP & RUN   ${RESET}"
echo -e "${BOLD}${YELLOW}====================================================${RESET}"

# 1. Check for Node.js
if ! command -v node &> /dev/null; then
    echo -e "${YELLOW}[!] Node.js not found. Attempting to install via Homebrew...${RESET}"
    
    # Check for Homebrew
    if ! command -v brew &> /dev/null; then
        echo -e "${YELLOW}[!] Homebrew not found. Installing Homebrew first...${RESET}"
        /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
        
        # Add brew to path for the current session
        if [[ $(uname -m) == "arm64" ]]; then
            eval "$(/opt/homebrew/bin/brew shellenv)"
        else
            eval "$(/usr/local/bin/brew shellenv)"
        fi
    fi
    
    echo -e "${GREEN}[*] Installing Node.js...${RESET}"
    brew install node
else
    echo -e "${GREEN}[✓] Node.js is already installed ($(node -v))${RESET}"
fi

# 2. Check for dependencies
echo -e "${GREEN}[*] Checking/Installing project dependencies...${RESET}"
if [ ! -d "node_modules" ]; then
    npm install
else
    # Quick check if packages are missing
    npm install --loglevel error
fi

# 3. Run the application
echo -e "${GREEN}[✓] Setup complete! Starting LoL Relay Sender...${RESET}"
echo ""
node index.js
